gui_state_default_create -off -ini

# Globals
gui_set_state_value -category Globals -key recent_cov_databases -value {/mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/Verificacion_RISCV_TEC/test_env/core_spi_uart/simv.vdb /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/Curso_Verif/Verificacion_Curso_2S_2018-master/Proyecto_3/Marco_Mora_Montoya/simv.vdb /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/Curso_Verif/Verificacion_Curso_2S_2018-master/Proyecto_4/Romell_Melendez/Result_mesi/simv.vdb /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/Curso_Verif/Verificacion_Curso_2S_2018-master/Proyecto_4/Ronny_Zarate_Ferreto/simv.vdb /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/Curso_Verif/Verificacion_Curso_2S_2018-master/Proyecto_4/Proyecto_4_Allen_Vargas_Rojas/simv.vdb}
gui_set_state_value -category Globals -key recent_databases -value {{gui_open_db -file /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/sim_files/core_sim_files/pre_synth_xori_test.vcd -design V1} {gui_open_db -file /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/sim_files/core_sim_files/post_synth_add_test.vcd -design V1} {gui_open_db -file /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/sim_files/core_sim_files/pre_synth_add_test.vcd -design V1} {gui_open_db -file /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/sim_files/core_sim_files/pre_synth_addi_test.vcd -design V1} {gui_open_db -file /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/sim_files/core_sim_files/topcore_tb.vcd -design V1}}

# Layout
gui_set_state_value -category Layout -key child_console_size_x -value 1249
gui_set_state_value -category Layout -key child_console_size_y -value 142
gui_set_state_value -category Layout -key child_covdetail_docknewline -value false
gui_set_state_value -category Layout -key child_covdetail_pos_x -value {-2}
gui_set_state_value -category Layout -key child_covdetail_pos_y -value {-15}
gui_set_state_value -category Layout -key child_covdetail_size_x -value 1046
gui_set_state_value -category Layout -key child_covdetail_size_y -value 317
gui_set_state_value -category Layout -key child_coveragemap_docknewline -value false
gui_set_state_value -category Layout -key child_coveragemap_pos_x -value {-2}
gui_set_state_value -category Layout -key child_coveragemap_pos_y -value {-15}
gui_set_state_value -category Layout -key child_coveragemap_size_x -value 1710
gui_set_state_value -category Layout -key child_coveragemap_size_y -value 725
gui_set_state_value -category Layout -key child_coveragetable_docknewline -value false
gui_set_state_value -category Layout -key child_coveragetable_pos_x -value {-2}
gui_set_state_value -category Layout -key child_coveragetable_pos_y -value {-15}
gui_set_state_value -category Layout -key child_coveragetable_size_x -value 1045
gui_set_state_value -category Layout -key child_coveragetable_size_y -value 316
gui_set_state_value -category Layout -key child_data_coltype -value 50
gui_set_state_value -category Layout -key child_data_colvalue -value 110
gui_set_state_value -category Layout -key child_data_colvariable -value 246
gui_set_state_value -category Layout -key child_data_size_x -value 203
gui_set_state_value -category Layout -key child_data_size_y -value 372
gui_set_state_value -category Layout -key child_hier_col3 -value {-1}
gui_set_state_value -category Layout -key child_hier_colhier -value 391
gui_set_state_value -category Layout -key child_hier_colpd -value 0
gui_set_state_value -category Layout -key child_hier_coltype -value 135
gui_set_state_value -category Layout -key child_hier_size_x -value 424
gui_set_state_value -category Layout -key child_hier_size_y -value 372
gui_set_state_value -category Layout -key child_schematic_pos_x -value {-2}
gui_set_state_value -category Layout -key child_schematic_pos_y -value {-15}
gui_set_state_value -category Layout -key child_schematic_size_x -value 310
gui_set_state_value -category Layout -key child_schematic_size_y -value 302
gui_set_state_value -category Layout -key child_source_docknewline -value false
gui_set_state_value -category Layout -key child_source_pos_x -value {-2}
gui_set_state_value -category Layout -key child_source_pos_y -value {-15}
gui_set_state_value -category Layout -key child_source_size_x -value 625
gui_set_state_value -category Layout -key child_source_size_y -value 367
gui_set_state_value -category Layout -key child_wave_colname -value 174
gui_set_state_value -category Layout -key child_wave_colvalue -value 174
gui_set_state_value -category Layout -key child_wave_docknewline -value false
gui_set_state_value -category Layout -key child_wave_left -value 353
gui_set_state_value -category Layout -key child_wave_pos_x -value {-2}
gui_set_state_value -category Layout -key child_wave_pos_y -value {-15}
gui_set_state_value -category Layout -key child_wave_right -value 860
gui_set_state_value -category Layout -key child_wave_size_x -value 1206
gui_set_state_value -category Layout -key child_wave_size_y -value 355
gui_set_state_value -category Layout -key cov_main_pos_x -value 37
gui_set_state_value -category Layout -key cov_main_pos_y -value 86
gui_set_state_value -category Layout -key cov_main_size_x -value 1277
gui_set_state_value -category Layout -key cov_main_size_y -value 690
gui_set_state_value -category Layout -key main_pos_x -value 13
gui_set_state_value -category Layout -key main_pos_y -value 77
gui_set_state_value -category Layout -key main_size_x -value 1262
gui_set_state_value -category Layout -key main_size_y -value 690
gui_set_state_value -category Layout -key stand_source_child_pos_x -value {-2}
gui_set_state_value -category Layout -key stand_source_child_pos_y -value {-15}
gui_set_state_value -category Layout -key stand_source_child_size_x -value 634
gui_set_state_value -category Layout -key stand_source_child_size_y -value 343
gui_set_state_value -category Layout -key stand_wave_child_docknewline -value false
gui_set_state_value -category Layout -key stand_wave_child_pos_x -value {-2}
gui_set_state_value -category Layout -key stand_wave_child_pos_y -value {-15}
gui_set_state_value -category Layout -key stand_wave_child_size_x -value 1223
gui_set_state_value -category Layout -key stand_wave_child_size_y -value 534
gui_set_state_value -category Layout -key stand_wave_top_pos_x -value 4
gui_set_state_value -category Layout -key stand_wave_top_pos_y -value 52
gui_set_state_value -category Layout -key stand_wave_top_size_x -value 1222
gui_set_state_value -category Layout -key stand_wave_top_size_y -value 690

# list_value_column

# Sim

# Assertion

# Stream

# Data

# TBGUI

# Driver

# Class

# Member

# ObjectBrowser

# UVM

# Local

# Backtrace

# FastSearch

# Exclusion

# SaveSession

# FindDialog
gui_create_state_key -category FindDialog -key m_pMatchCase -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pMatchWord -value_type bool -value false
gui_create_state_key -category FindDialog -key m_pUseCombo -value_type string -value {}
gui_create_state_key -category FindDialog -key m_pWrapAround -value_type bool -value true

# Widget_History
gui_create_state_key -category Widget_History -key TopLevel.1|qt_left_dock|DockWnd2|DLPane.1|pages|Data.1|hbox|textfilter -value_type string -value pc
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_VPDCombo} -value_type string -value inter.vpd
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_curDirCombo} -value_type string -value {/mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/Verificacion_RISCV_TEC/test_env/core_spi_uart /mnt/vol_NFS_Zener/WD_ESPEC/rmolina/riscv_test/Verificacion_RISCV_TEC/test_env/core}
gui_create_state_key -category Widget_History -key {dlgSimSetup|m_setupTab|tab pages|SimTab|m_exeCombo} -value_type string -value ./simv

# Layout_CoverageTable_covtblFGroupsList
gui_create_state_key -category Layout_CoverageTable_covtblFGroupsList -key names -value_type string -value {Group,    , ,  ,   ,Score,Covergroup,}
gui_create_state_key -category Layout_CoverageTable_covtblFGroupsList -key orders -value_type string -value 4,0,1,2,3,5,6,
gui_create_state_key -category Layout_CoverageTable_covtblFGroupsList -key widths -value_type string -value 220,0,25,0,0,125,125,

# Layout_CoverageTable_covtblInstancesList
gui_create_state_key -category Layout_CoverageTable_covtblInstancesList -key names -value_type string -value {Name,    , ,  ,   ,Score,Line,Toggle,FSM,Condition,Branch,}
gui_create_state_key -category Layout_CoverageTable_covtblInstancesList -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,
gui_create_state_key -category Layout_CoverageTable_covtblInstancesList -key widths -value_type string -value 220,0,25,0,0,125,125,125,125,125,125,

# Layout_CoverageTable_covtblModulesList
gui_create_state_key -category Layout_CoverageTable_covtblModulesList -key names -value_type string -value {Name,    , ,  ,   ,Score,Line,Toggle,FSM,Condition,Branch,}
gui_create_state_key -category Layout_CoverageTable_covtblModulesList -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,
gui_create_state_key -category Layout_CoverageTable_covtblModulesList -key widths -value_type string -value 220,0,25,0,0,125,125,125,125,125,125,

# Layout_CovDetail_lnListView
gui_create_state_key -category Layout_CovDetail_lnListView -key names -value_type string -value Category,Coverage,
gui_create_state_key -category Layout_CovDetail_lnListView -key orders -value_type string -value 0,1,
gui_create_state_key -category Layout_CovDetail_lnListView -key widths -value_type string -value 111,125,

# Layout_CovDetail_tglListView
gui_create_state_key -category Layout_CovDetail_tglListView -key names -value_type string -value {Variable, ,  ,   ,Type,Coverage,Display,}
gui_create_state_key -category Layout_CovDetail_tglListView -key orders -value_type string -value 3,0,1,2,4,5,6,
gui_create_state_key -category Layout_CovDetail_tglListView -key widths -value_type string -value 140,25,0,0,50,125,586,

# Layout_CovDetail_tglDetailListView
gui_create_state_key -category Layout_CovDetail_tglDetailListView -key names -value_type string -value {Variable, ,  ,   ,0->1,1->0,}
gui_create_state_key -category Layout_CovDetail_tglDetailListView -key orders -value_type string -value 3,0,1,2,4,5,
gui_create_state_key -category Layout_CovDetail_tglDetailListView -key widths -value_type string -value 140,25,0,0,50,50,

# Layout_CovDetail_fsmListView
gui_create_state_key -category Layout_CovDetail_fsmListView -key names -value_type string -value {FSM, ,  ,   ,State,Transition,Sequence,}
gui_create_state_key -category Layout_CovDetail_fsmListView -key orders -value_type string -value 3,0,1,2,5,4,6,
gui_create_state_key -category Layout_CovDetail_fsmListView -key widths -value_type string -value 66,25,0,0,125,125,125,

# Layout_CovDetail_fsmlist
gui_create_state_key -category Layout_CovDetail_fsmlist -key names -value_type string -value {Coverage, ,  ,   ,Transition,}
gui_create_state_key -category Layout_CovDetail_fsmlist -key orders -value_type string -value 3,0,1,2,4,
gui_create_state_key -category Layout_CovDetail_fsmlist -key widths -value_type string -value 125,25,0,0,70,

# Layout_CovDetail_cndListView
gui_create_state_key -category Layout_CovDetail_cndListView -key names -value_type string -value {Expression, ,  ,   ,ID,Coverage,Line No.,}
gui_create_state_key -category Layout_CovDetail_cndListView -key orders -value_type string -value 3,0,1,2,4,5,6,
gui_create_state_key -category Layout_CovDetail_cndListView -key widths -value_type string -value 320,25,0,0,0,125,63,

# Layout_CovDetail_brListView
gui_create_state_key -category Layout_CovDetail_brListView -key names -value_type string -value {Name, ,  ,   ,Coverage,Line No.,}
gui_create_state_key -category Layout_CovDetail_brListView -key orders -value_type string -value 3,0,1,2,4,5,
gui_create_state_key -category Layout_CovDetail_brListView -key widths -value_type string -value 100,25,0,0,125,63,

# Layout_CovDetail_designAssertListView
gui_create_state_key -category Layout_CovDetail_designAssertListView -key names -value_type string -value {Assert Name,    , ,  ,   ,Attempts,Real Successes,Failures,Incompletes,Category,Severity,}
gui_create_state_key -category Layout_CovDetail_designAssertListView -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,
gui_create_state_key -category Layout_CovDetail_designAssertListView -key widths -value_type string -value 110,0,25,0,0,63,106,61,82,67,62,

# Layout_CovDetail_codeMiddleSplitter
gui_create_state_key -category Layout_CovDetail_codeMiddleSplitter -key value1 -value_type integer -value 10
gui_create_state_key -category Layout_CovDetail_codeMiddleSplitter -key value2 -value_type integer -value 296

# Layout_CovDetail_cndSplitter
gui_create_state_key -category Layout_CovDetail_cndSplitter -key value1 -value_type integer -value 100
gui_create_state_key -category Layout_CovDetail_cndSplitter -key value2 -value_type integer -value 197

# Layout_CovDetail_covGrpInsListView
gui_create_state_key -category Layout_CovDetail_covGrpInsListView -key names -value_type string -value {Cover Group Item,    , ,  ,   ,Definition,Score,Goal,Weight,At Least,Per Instance,Overlap,Auto Bin Max,Print Missing,Comment,}
gui_create_state_key -category Layout_CovDetail_covGrpInsListView -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,11,12,13,14,
gui_create_state_key -category Layout_CovDetail_covGrpInsListView -key widths -value_type string -value 137,0,25,0,0,68,125,30,42,50,74,0,80,76,55,

# Layout_CovDetail_covGrpDefListView
gui_create_state_key -category Layout_CovDetail_covGrpDefListView -key names -value_type string -value {Cover Group Item,    , ,  ,   ,Score,Goal,Weight,At Least,Per Instance,Overlap,Auto Bin Max,Print Missing,Comment,}
gui_create_state_key -category Layout_CovDetail_covGrpDefListView -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,11,12,13,
gui_create_state_key -category Layout_CovDetail_covGrpDefListView -key widths -value_type string -value 172,0,25,0,0,125,66,78,86,110,0,116,112,91,

# Layout_CovDetail_m_CovGrpTable
gui_create_state_key -category Layout_CovDetail_m_CovGrpTable -key names -value_type string -value {Bin Name,    , ,  ,   ,Status,Cross,At Least,Size,Hit Count,}
gui_create_state_key -category Layout_CovDetail_m_CovGrpTable -key orders -value_type string -value 5,0,1,2,3,4,6,7,8,9,
gui_create_state_key -category Layout_CovDetail_m_CovGrpTable -key widths -value_type string -value 249,0,25,0,0,150,0,62,40,68,

# Layout_CovDetail_assertion list
gui_create_state_key -category {Layout_CovDetail_assertion list} -key names -value_type string -value {Instance,    , ,  ,   ,Assert Name,Attempts,Real Successes,Failures,Incompletes,Category,Severity,}
gui_create_state_key -category {Layout_CovDetail_assertion list} -key orders -value_type string -value 4,0,1,2,3,5,6,7,8,9,10,11,
gui_create_state_key -category {Layout_CovDetail_assertion list} -key widths -value_type string -value 86,0,25,0,0,112,87,130,110,106,91,86,

# Layout_CovDetail_funMiddleSplitter
gui_create_state_key -category Layout_CovDetail_funMiddleSplitter -key value1 -value_type integer -value 508
gui_create_state_key -category Layout_CovDetail_funMiddleSplitter -key value2 -value_type integer -value 508

# Layout_CovDetail_splitterWithPrefVal
gui_create_state_key -category Layout_CovDetail_splitterWithPrefVal -key value1 -value_type integer -value 100
gui_create_state_key -category Layout_CovDetail_splitterWithPrefVal -key value2 -value_type integer -value 1


gui_state_default_create -off
